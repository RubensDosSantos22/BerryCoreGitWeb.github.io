* (January 27, 2016)
	- Main folders renamed, structure adjusted accoring to general template
* (January 25, 2016)
	- MAJOR UPDATE: structure modified, grunt tasks updated, all assets moved to 'static' folder, liquid templates updated using jade blocks, 'type' conditions removed
* (September 20, 2015)
	- Search feature added, dropdown menu issue fixed
* (September 17, 2015)
	- Font variables for each block added
* (September 11, 2015)
	- Data files and _config updated
* (September 06, 2015)
	- block structure updated
* (August 30, 2015)
	- ie8 issue fixed
* (August 20, 2015)
	- posting script modified
* (July 28, 2015)
	- post images separated, using updated structure
* (July 27, 2015)
	- image structure modified, jsthumb aspect fixed, grunt watch task fixed
* (July 15, 2015)
	- locales moved to _data/locales
* (July 14, 2015)
	- i18n files reorganized - moved to data folder
* (July 13, 2015)
	- Share section added
* (July 12, 2015)
	- I18n using jekyll-i18n-filter plugin added
* (July 11, 2015)
	- Archive page added
* (July 10, 2015)
	- Post and pages attribution added
* (July 07, 2015)
	- thumbnail img fit resize script added, watch coffe task updated
* (July 06, 2015)
	- Copy task replaced by sync
* (July 06, 2015)
	- data folder moved to _publ folder
* (July 02, 2015)
	- Styles structure upd, elements lib replaced by autoprefixer and mixins lib
* (May 28, 2015)
	- Structure changed, blogging content separated 
* (May 26, 2015)
	- New post with bash script added
* (May 25, 2015)
	- Sublime snippets removed in favour of using bash script
* (May 22, 2015)
	- Used grunt-load-config instead of require-dir
* (May 21, 2015)
	- Grunt tasks structure modified using separated tasks
* (April 30, 2015)
	- Templates and styles structure refactored, data driven nav added
* (April 25, 2015)
	- Categories and tag pagination added
* (April 22, 2015)
	- Categories and tag support, templates structure modified
* (December 30, 2014)
	- Added Disqus coments
* (December 05, 2014)
	- Custom theme developed, ready for blogging
* (November 29, 2014)
	- Basic theme with lorem ipsum installed
* (November 28, 2014)
	- Powered by Grunt, Bower, Jade, Sass
* (November 17, 2014)
	- Moved to jekyll
* (November 15, 2014)
	- Initial commit
